package automation.contanst;

public class CT_AladaLoginPage {
	public static final String EMAIL_INPUT = "txtLoginUsername";
	public static final String PASS_INPUT = "txtLoginPassword";
	public static final String LOGIN_BTN = "//div[@class = 'field']/button[text() = 'ĐĂNG NHẬP']";
	public static final String NOT_SIGN_ERROR = "//p[text() = 'Email này chưa được đăng ký.']";
}

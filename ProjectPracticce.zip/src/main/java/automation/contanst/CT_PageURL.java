package automation.contanst;

public class CT_PageURL {
	public static final String MAGNETO_URL = "https://magento.softwaretestingboard.com/";
	public static final String CODESTART_URL = "https://codestar.vn/";
	public static final String ALADA_URL = "https://alada.vn/tai-khoan/dang-nhap.html";
	
}

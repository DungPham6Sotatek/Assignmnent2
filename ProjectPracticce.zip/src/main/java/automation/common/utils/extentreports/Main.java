package automation.common.utils.extentreports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Main {
    public static void main(String[] args) {
        // Khởi tạo báo cáo với ExtentSparkReporter
        ExtentSparkReporter sparkReporter = new ExtentSparkReporter("ExtentReports/simple_report.html");
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(sparkReporter);

        // Tạo một bài kiểm thử trong báo cáo
        ExtentTest test = extent.createTest("Simple Test", "This is a simple test case");
        test.pass("Test passed");

        // Ghi báo cáo vào tệp
        extent.flush();
    }
}
